package Enum;

public enum Canal {

		CAJERO,
	    VENTANILLA,
	    ONLINE,
	    MOBILE
}
