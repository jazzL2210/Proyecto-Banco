package Enum;

public enum TipoCuenta {

	AHORRO,
	CLIENTE,
	PLAZO_FIJO
}
