package Enum;

public enum EstadoCliente {
	ACTIVO,
	INACTIVO,
	BLOQUEADO
}
