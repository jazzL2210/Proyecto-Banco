package Enum;

public enum TipoMovimiento {

		DEPOSITO,
	    RETIRO,
	    TRANSFERENCIA_ENVIADA,
	    TRANSFERENCIA_RECIBIDA
}
