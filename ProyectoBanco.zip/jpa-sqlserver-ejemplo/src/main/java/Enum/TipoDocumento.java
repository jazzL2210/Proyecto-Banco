package Enum;

public enum TipoDocumento {
    CEDULA,
    DNI,
    PASAPORTE
}
