package Enum;

public enum EstadoCuenta {
	   	ACTIVA,
	    INACTIVA,
	    CERRADA,
	    BLOQUEADA
}
